import { Mail, MapPin, MessageCircle, Maximize2, BedDouble, ImageOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  type Listing,
  dealLabel,
  emailLink,
  formatPrice,
  roleLabel,
  typeLabel,
  whatsappLink,
} from "@/lib/properties";

export function ListingCard({ l }: { l: Listing }) {
  const photo = l.photos[0];
  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl border bg-card shadow-card transition-shadow hover:shadow-lift">
      <div className="relative aspect-[4/3] overflow-hidden bg-muted">
        {photo ? (
          <img
            src={photo}
            alt={l.title}
            loading="lazy"
            width={1024}
            height={768}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="grid h-full place-items-center text-muted-foreground">
            <ImageOff className="h-8 w-8" />
          </div>
        )}
        <div className="absolute left-3 top-3 flex gap-2">
          <span className="rounded-full bg-accent px-3 py-1 text-xs font-bold text-accent-foreground">
            For {dealLabel(l.transaction_type)}
          </span>
          <span className="rounded-full bg-card/95 px-3 py-1 text-xs font-semibold text-card-foreground">
            {typeLabel(l.property_type)}
          </span>
        </div>
        {l.isSample && (
          <span className="absolute right-3 top-3 rounded-full bg-foreground/80 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-background">
            Example
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-3 p-5">
        <div>
          <p className="font-display text-2xl font-bold text-primary">
            {formatPrice(l.price, l.transaction_type)}
          </p>
          <h3 className="mt-1 text-lg font-semibold leading-snug">{l.title}</h3>
          <p className="mt-1 flex items-center gap-1 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4 shrink-0" /> {l.locality}, {l.location}
          </p>
        </div>

        <div className="flex flex-wrap gap-4 text-sm text-foreground/80">
          {l.area_sqft && (
            <span className="flex items-center gap-1.5">
              <Maximize2 className="h-4 w-4 text-muted-foreground" />
              {l.area_sqft.toLocaleString("en-IN")} sq ft
            </span>
          )}
          {l.bedrooms != null && l.bedrooms > 0 && (
            <span className="flex items-center gap-1.5">
              <BedDouble className="h-4 w-4 text-muted-foreground" />
              {l.bedrooms} BHK
            </span>
          )}
        </div>

        <p className="line-clamp-2 text-sm text-muted-foreground">{l.description}</p>

        <div className="mt-auto border-t pt-4">
          <p className="mb-3 text-sm">
            <span className="font-semibold">{l.advertiser_name}</span>
            <span className="ml-2 rounded-md bg-secondary px-2 py-0.5 text-xs font-medium text-secondary-foreground">
              {roleLabel(l.advertiser_role)}
            </span>
          </p>
          <div className="grid grid-cols-2 gap-2">
            <Button asChild variant="whatsapp">
              <a href={whatsappLink(l)} target="_blank" rel="noopener noreferrer">
                <MessageCircle /> WhatsApp
              </a>
            </Button>
            <Button asChild variant="outline">
              <a href={emailLink(l)}>
                <Mail /> Email
              </a>
            </Button>
          </div>
        </div>
      </div>
    </article>
  );
}
