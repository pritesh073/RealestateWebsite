import { Building2, Home, Castle, Warehouse, Briefcase, Trees, type LucideProps } from "lucide-react";

const map = { flat: Building2, house: Home, bungalow: Castle, warehouse: Warehouse, office: Briefcase, plot: Trees };

export function PropertyIcon({ type, ...props }: { type: string } & LucideProps) {
  const Icon = map[type as keyof typeof map] ?? Building2;
  return <Icon {...props} />;
}
