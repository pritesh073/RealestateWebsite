import { Link } from "@tanstack/react-router";
import { Building2, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b bg-background/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6">
        <Link to="/" className="flex min-w-0 items-center gap-2">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-primary text-primary-foreground">
            <Building2 className="h-5 w-5" />
          </span>
          <span className="truncate font-display text-lg font-bold">GharGhar</span>
        </Link>
        <nav className="flex items-center gap-1 sm:gap-2">
          <Link
            to="/listings"
            className="rounded-md px-3 py-2 text-sm font-medium hover:bg-secondary"
            activeProps={{ className: "text-primary" }}
          >
            Browse
          </Link>
          <Button asChild variant="accent" size="sm">
            <Link to="/post">
              <Plus /> <span className="hidden sm:inline">Post property</span>
              <span className="sm:hidden">Post</span>
            </Link>
          </Button>
        </nav>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-20 border-t bg-secondary/50">
      <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-8 text-sm text-muted-foreground sm:flex-row sm:justify-between sm:px-6">
        <p>© {new Date().getFullYear()} GharGhar · Properties across Mumbai, Navi Mumbai, Thane & Kalyan</p>
        <p>Listings marked “Example” are sample data for demonstration.</p>
      </div>
    </footer>
  );
}
