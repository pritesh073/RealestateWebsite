import flat from "@/assets/p-flat.jpg";
import bungalow from "@/assets/p-bungalow.jpg";
import office from "@/assets/p-office.jpg";
import warehouse from "@/assets/p-warehouse.jpg";
import plot from "@/assets/p-plot.jpg";

export const PROPERTY_TYPES = [
  { value: "flat", label: "Flat / Apartment", icon: "Building2" },
  { value: "house", label: "Independent House", icon: "Home" },
  { value: "bungalow", label: "Bungalow", icon: "Castle" },
  { value: "warehouse", label: "Warehouse", icon: "Warehouse" },
  { value: "office", label: "Office", icon: "Briefcase" },
  { value: "plot", label: "Plot / Land", icon: "Trees" },
] as const;

export const DEAL_TYPES = [
  { value: "buy", label: "Buy", hint: "Own a property" },
  { value: "lease", label: "Lease", hint: "Long-term lease" },
  { value: "rent", label: "Rent", hint: "Monthly rental" },
] as const;

export const LOCATIONS = ["Mumbai", "Navi Mumbai", "Thane", "Kalyan"] as const;
export const ROLES = [
  { value: "owner", label: "Owner" },
  { value: "agent", label: "Agent" },
  { value: "builder", label: "Builder" },
] as const;

export type PropertyType = (typeof PROPERTY_TYPES)[number]["value"];
export type DealType = (typeof DEAL_TYPES)[number]["value"];
export type Role = (typeof ROLES)[number]["value"];

export interface Listing {
  id: string;
  title: string;
  property_type: PropertyType;
  transaction_type: DealType;
  location: string;
  locality: string;
  price: number;
  area_sqft: number | null;
  bedrooms: number | null;
  description: string;
  photos: string[];
  advertiser_name: string;
  advertiser_role: Role;
  phone: string;
  email: string;
  created_at: string;
  isSample?: boolean;
}

export const typeLabel = (v: string) => PROPERTY_TYPES.find((t) => t.value === v)?.label ?? v;
export const dealLabel = (v: string) => DEAL_TYPES.find((t) => t.value === v)?.label ?? v;
export const roleLabel = (v: string) => ROLES.find((t) => t.value === v)?.label ?? v;

export function formatPrice(price: number, deal: string) {
  let s: string;
  if (price >= 1e7) s = `₹${(price / 1e7).toFixed(2).replace(/\.?0+$/, "")} Cr`;
  else if (price >= 1e5) s = `₹${(price / 1e5).toFixed(2).replace(/\.?0+$/, "")} L`;
  else s = `₹${price.toLocaleString("en-IN")}`;
  return deal === "buy" ? s : `${s} / month`;
}

export function whatsappLink(l: Listing) {
  const digits = l.phone.replace(/\D/g, "");
  const num = digits.length === 10 ? `91${digits}` : digits;
  const msg = `Hi ${l.advertiser_name}, I'm interested in your listing "${l.title}" (${l.locality}, ${l.location}). Is it still available?`;
  return `https://wa.me/${num}?text=${encodeURIComponent(msg)}`;
}

export function emailLink(l: Listing) {
  const subject = `Enquiry: ${l.title}`;
  const body = `Hello ${l.advertiser_name},\n\nI saw your ${typeLabel(l.property_type)} listing for ${dealLabel(l.transaction_type).toLowerCase()} in ${l.locality}, ${l.location} (${formatPrice(l.price, l.transaction_type)}).\n\nI'd like to know more and arrange a visit. Please get in touch.\n\nMy name:\nMy phone:\n\nThank you.`;
  return `mailto:${l.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

const d = (n: number) => new Date(Date.now() - n * 86400000).toISOString();

export const SAMPLE_LISTINGS: Listing[] = [
  { id: "s1", title: "Sea-view 3 BHK in Worli tower", property_type: "flat", transaction_type: "buy", location: "Mumbai", locality: "Worli", price: 58000000, area_sqft: 1450, bedrooms: 3, description: "High-floor apartment with uninterrupted sea views, modular kitchen, two covered parking slots and a clubhouse with pool.", photos: [flat], advertiser_name: "Rohan Mehta", advertiser_role: "agent", phone: "9800000001", email: "rohan@example.com", created_at: d(1), isSample: true },
  { id: "s2", title: "Spacious bungalow with garden", property_type: "bungalow", transaction_type: "buy", location: "Thane", locality: "Ghodbunder Road", price: 42500000, area_sqft: 3200, bedrooms: 4, description: "Independent two-storey bungalow on a gated lane, landscaped garden, terrace and servant quarters. Ready to move.", photos: [bungalow], advertiser_name: "Sunita Kulkarni", advertiser_role: "owner", phone: "9800000002", email: "sunita@example.com", created_at: d(3), isSample: true },
  { id: "s3", title: "Furnished office near station", property_type: "office", transaction_type: "lease", location: "Navi Mumbai", locality: "Vashi", price: 185000, area_sqft: 2100, bedrooms: null, description: "Plug-and-play office with 30 workstations, 2 cabins, conference room and 24×7 power backup. 5 minutes from Vashi station.", photos: [office], advertiser_name: "Skyline Realty", advertiser_role: "agent", phone: "9800000003", email: "leasing@example.com", created_at: d(2), isSample: true },
  { id: "s4", title: "Grade-A warehouse with docks", property_type: "warehouse", transaction_type: "lease", location: "Thane", locality: "Bhiwandi", price: 950000, area_sqft: 45000, bedrooms: null, description: "Pre-engineered warehouse with 8 loading docks, 12 m clear height, wide approach road and fire safety compliance.", photos: [warehouse], advertiser_name: "Patil Logistics Parks", advertiser_role: "builder", phone: "9800000004", email: "parks@example.com", created_at: d(6), isSample: true },
  { id: "s5", title: "Clear-title NA plot", property_type: "plot", transaction_type: "buy", location: "Kalyan", locality: "Titwala", price: 3500000, area_sqft: 2500, bedrooms: null, description: "Non-agricultural plot with compound wall, road access and electricity connection nearby. Ideal for a weekend home.", photos: [plot], advertiser_name: "Anil Deshmukh", advertiser_role: "owner", phone: "9800000005", email: "anil@example.com", created_at: d(8), isSample: true },
  { id: "s6", title: "2 BHK for rent, semi-furnished", property_type: "flat", transaction_type: "rent", location: "Navi Mumbai", locality: "Kharghar", price: 32000, area_sqft: 980, bedrooms: 2, description: "Well-ventilated flat with wardrobes, ACs in bedrooms and society gym. Close to Central Park and schools.", photos: [flat], advertiser_name: "Priya Nair", advertiser_role: "owner", phone: "9800000006", email: "priya@example.com", created_at: d(4), isSample: true },
  { id: "s7", title: "Independent house in quiet lane", property_type: "house", transaction_type: "rent", location: "Kalyan", locality: "Khadakpada", price: 28000, area_sqft: 1300, bedrooms: 3, description: "Ground-plus-one house with private parking and a small sit-out. Families preferred.", photos: [bungalow], advertiser_name: "Shree Homes", advertiser_role: "builder", phone: "9800000007", email: "shree@example.com", created_at: d(5), isSample: true },
  { id: "s8", title: "Premium office floor, BKC", property_type: "office", transaction_type: "rent", location: "Mumbai", locality: "Bandra Kurla Complex", price: 650000, area_sqft: 4200, bedrooms: null, description: "Bare-shell floor in a LEED-certified building, ideal for corporate HQ. Ample visitor parking.", photos: [office], advertiser_name: "Vikram Shah", advertiser_role: "agent", phone: "9800000008", email: "vikram@example.com", created_at: d(7), isSample: true },
];
