import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { SAMPLE_LISTINGS, type Listing } from "@/lib/properties";

async function fetchListings(): Promise<Listing[]> {
  const { data, error } = await supabase
    .from("listings")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(200);
  if (error) throw error;
  const rows = (data ?? []) as unknown as Listing[];
  const paths = rows.flatMap((r) => r.photos);
  const urlMap = new Map<string, string>();
  if (paths.length) {
    const { data: signed } = await supabase.storage
      .from("listing-photos")
      .createSignedUrls(paths, 60 * 60 * 24);
    signed?.forEach((s) => s.path && s.signedUrl && urlMap.set(s.path, s.signedUrl));
  }
  return rows.map((r) => ({
    ...r,
    price: Number(r.price),
    photos: r.photos.map((p) => urlMap.get(p)).filter(Boolean) as string[],
  }));
}

export function useListings() {
  const q = useQuery({ queryKey: ["listings"], queryFn: fetchListings });
  return { ...q, all: [...(q.data ?? []), ...SAMPLE_LISTINGS] };
}
