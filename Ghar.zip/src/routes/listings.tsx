import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMemo } from "react";
import { SlidersHorizontal, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ListingCard } from "@/components/ListingCard";
import { useListings } from "@/hooks/use-listings";
import { DEAL_TYPES, LOCATIONS, PROPERTY_TYPES, ROLES } from "@/lib/properties";

type Search = {
  deal?: string;
  type?: string;
  location?: string;
  role?: string;
  q?: string;
  maxPrice?: number;
  sort?: string;
};

const str = (v: unknown) => (typeof v === "string" ? v.slice(0, 80) : "");

export const Route = createFileRoute("/listings")({
  validateSearch: (r: Record<string, unknown>): Search => ({
    deal: str(r["deal"]),
    type: str(r["type"]),
    location: str(r["location"]),
    role: str(r["role"]),
    q: str(r["q"]),
    maxPrice: Number(r["maxPrice"]) || 0,
    sort: str(r["sort"]) || "newest",
  }),
  head: () => ({
    meta: [
      { title: "Browse properties — GharGhar" },
      { name: "description", content: "Filter flats, houses, offices, warehouses and plots by location, price and type across the Mumbai region." },
      { property: "og:title", content: "Browse properties — GharGhar" },
      { property: "og:description", content: "Filter and sort property listings, then contact advertisers directly." },
    ],
  }),
  component: ListingsPage,
});

const sel = "h-10 w-full rounded-lg border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring";

function ListingsPage() {
  const raw = Route.useSearch();
  const s = {
    deal: raw.deal ?? "", type: raw.type ?? "", location: raw.location ?? "", role: raw.role ?? "",
    q: raw.q ?? "", maxPrice: raw.maxPrice ?? 0, sort: raw.sort ?? "newest",
  };
  const navigate = useNavigate({ from: "/listings" });
  const { all, isLoading } = useListings();
  const set = (patch: Search) => navigate({ search: (p) => ({ ...p, ...patch }), replace: true });

  const results = useMemo(() => {
    const q = s.q.toLowerCase().slice(0, 80);
    const r = all.filter(
      (l) =>
        (!s.deal || l.transaction_type === s.deal) &&
        (!s.type || l.property_type === s.type) &&
        (!s.location || l.location === s.location) &&
        (!s.role || l.advertiser_role === s.role) &&
        (!s.maxPrice || l.price <= s.maxPrice) &&
        (!q || `${l.title} ${l.locality} ${l.description}`.toLowerCase().includes(q)),
    );
    const sorters: Record<string, (a: typeof r[0], b: typeof r[0]) => number> = {
      newest: (a, b) => b.created_at.localeCompare(a.created_at),
      "price-asc": (a, b) => a.price - b.price,
      "price-desc": (a, b) => b.price - a.price,
      "area-desc": (a, b) => (b.area_sqft ?? 0) - (a.area_sqft ?? 0),
    };
    return [...r].sort(sorters[s.sort] ?? sorters["newest"]!);
  }, [all, s]);

  const active = s.deal || s.type || s.location || s.role || s.q || s.maxPrice;

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
      <h1 className="text-3xl font-bold sm:text-4xl">Browse properties</h1>
      <p className="mt-1 text-muted-foreground">
        {isLoading ? "Loading…" : `${results.length} ${results.length === 1 ? "property" : "properties"} found`}
      </p>

      <div className="mt-6 rounded-2xl border bg-card p-4 shadow-card">
        <div className="mb-3 flex items-center gap-2 text-sm font-semibold">
          <SlidersHorizontal className="h-4 w-4" /> Filters
          {active ? (
            <Button variant="ghost" size="sm" className="ml-auto"
              onClick={() => navigate({ search: { deal: "", type: "", location: "", role: "", q: "", maxPrice: 0, sort: s.sort } })}>
              <X /> Clear
            </Button>
          ) : null}
        </div>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-7">
          <input aria-label="Search" className={`${sel} col-span-2 md:col-span-4 lg:col-span-1`} placeholder="Search locality…" value={s.q} maxLength={80} onChange={(e) => set({ q: e.target.value })} />
          <select aria-label="Deal" className={sel} value={s.deal} onChange={(e) => set({ deal: e.target.value })}>
            <option value="">Buy / Lease / Rent</option>
            {DEAL_TYPES.map((d) => <option key={d.value} value={d.value}>{d.label}</option>)}
          </select>
          <select aria-label="Property type" className={sel} value={s.type} onChange={(e) => set({ type: e.target.value })}>
            <option value="">All types</option>
            {PROPERTY_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
          </select>
          <select aria-label="Location" className={sel} value={s.location} onChange={(e) => set({ location: e.target.value })}>
            <option value="">All locations</option>
            {LOCATIONS.map((l) => <option key={l}>{l}</option>)}
          </select>
          <select aria-label="Advertiser" className={sel} value={s.role} onChange={(e) => set({ role: e.target.value })}>
            <option value="">Any advertiser</option>
            {ROLES.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
          </select>
          <select aria-label="Max price" className={sel} value={s.maxPrice} onChange={(e) => set({ maxPrice: Number(e.target.value) })}>
            <option value={0}>Any price</option>
            <option value={50000}>Up to ₹50,000</option>
            <option value={500000}>Up to ₹5 L</option>
            <option value={5000000}>Up to ₹50 L</option>
            <option value={20000000}>Up to ₹2 Cr</option>
            <option value={50000000}>Up to ₹5 Cr</option>
          </select>
          <select aria-label="Sort" className={sel} value={s.sort} onChange={(e) => set({ sort: e.target.value })}>
            <option value="newest">Newest first</option>
            <option value="price-asc">Price: low to high</option>
            <option value="price-desc">Price: high to low</option>
            <option value="area-desc">Largest area</option>
          </select>
        </div>
      </div>

      {results.length ? (
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {results.map((l) => <ListingCard key={l.id} l={l} />)}
        </div>
      ) : (
        <div className="mt-12 rounded-2xl border border-dashed p-12 text-center text-muted-foreground">
          No properties match these filters. Try widening your search.
        </div>
      )}
    </div>
  );
}
