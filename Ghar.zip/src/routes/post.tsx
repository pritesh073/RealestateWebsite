import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { ImagePlus, Loader2, X } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { DEAL_TYPES, LOCATIONS, PROPERTY_TYPES, ROLES } from "@/lib/properties";

export const Route = createFileRoute("/post")({
  head: () => ({
    meta: [
      { title: "Post a property — GharGhar" },
      { name: "description", content: "Owners, agents and builders: list your flat, house, office, warehouse or plot for sale, rent or lease." },
      { property: "og:title", content: "Post a property — GharGhar" },
      { property: "og:description", content: "Advertise your property to buyers and tenants across the Mumbai region." },
    ],
  }),
  component: PostPage,
});

const schema = z.object({
  title: z.string().trim().min(3, "Add a title").max(120),
  property_type: z.enum(["flat", "house", "bungalow", "warehouse", "office", "plot"]),
  transaction_type: z.enum(["buy", "lease", "rent"]),
  location: z.enum(LOCATIONS),
  locality: z.string().trim().min(2, "Add a locality").max(80),
  price: z.coerce.number().positive("Enter a valid price").max(99999999999),
  area_sqft: z.coerce.number().int().positive().max(9999999).optional(),
  bedrooms: z.coerce.number().int().min(0).max(50).optional(),
  description: z.string().trim().min(10, "Describe the property (min 10 characters)").max(1000),
  advertiser_name: z.string().trim().min(2, "Enter your name").max(80),
  advertiser_role: z.enum(["owner", "agent", "builder"]),
  phone: z.string().trim().regex(/^[0-9]{10,13}$/, "Enter 10–13 digits, e.g. 9876543210"),
  email: z.string().trim().email("Enter a valid email").max(255),
});

const field = "h-11 w-full rounded-lg border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring";

function PostPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [files, setFiles] = useState<File[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);

  const addFiles = (list: FileList | null) => {
    if (!list) return;
    const next = [...files, ...Array.from(list)].filter((f) => f.type.startsWith("image/") && f.size <= 5 * 1024 * 1024).slice(0, 6);
    if (next.length < files.length + list.length) toast.warning("Only images up to 5 MB, maximum 6 photos.");
    setFiles(next);
  };

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const raw = Object.fromEntries(new FormData(e.currentTarget));
    for (const k of ["area_sqft", "bedrooms"]) if (raw[k] === "") delete raw[k];
    const parsed = schema.safeParse(raw);
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      parsed.error.issues.forEach((i) => (errs[String(i.path[0])] ??= i.message));
      setErrors(errs);
      toast.error("Please fix the highlighted fields.");
      return;
    }
    setErrors({});
    setBusy(true);
    try {
      const paths: string[] = [];
      for (const f of files) {
        const ext = f.name.split(".").pop()?.toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
        const path = `${crypto.randomUUID()}.${ext}`;
        const { error } = await supabase.storage.from("listing-photos").upload(path, f, { contentType: f.type });
        if (error) throw error;
        paths.push(path);
      }
      const { error } = await supabase.from("listings").insert({ ...parsed.data, area_sqft: parsed.data.area_sqft ?? null, bedrooms: parsed.data.bedrooms ?? null, photos: paths });
      if (error) throw error;
      await qc.invalidateQueries({ queryKey: ["listings"] });
      toast.success("Your property is live!");
      navigate({ to: "/listings" });
    } catch (err) {
      console.error(err);
      toast.error("Couldn't publish your listing. Please try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
      <h1 className="text-3xl font-bold sm:text-4xl">Post a property</h1>
      <p className="mt-2 text-muted-foreground">Fill in the details below. Customers will contact you on WhatsApp or email.</p>

      <form onSubmit={submit} noValidate className="mt-8 space-y-8">
        <Fieldset title="Property">
          <F label="Listing title" name="title" err={errors["title"]} full><input name="title" className={field} placeholder="e.g. 2 BHK with balcony near station" maxLength={120} /></F>
          <F label="Property type" name="property_type"><select name="property_type" className={field}>{PROPERTY_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}</select></F>
          <F label="Available for" name="transaction_type"><select name="transaction_type" className={field}>{DEAL_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label === "Buy" ? "Sale" : t.label}</option>)}</select></F>
          <F label="Price (₹ — total for sale, monthly for rent/lease)" name="price" err={errors["price"]}><input name="price" type="number" min={1} className={field} placeholder="e.g. 7500000" /></F>
          <F label="Area (sq ft)" name="area_sqft" err={errors["area_sqft"]}><input name="area_sqft" type="number" min={1} className={field} placeholder="Optional" /></F>
          <F label="Bedrooms (BHK)" name="bedrooms" err={errors["bedrooms"]}><input name="bedrooms" type="number" min={0} max={50} className={field} placeholder="Optional" /></F>
          <F label="Description" name="description" err={errors["description"]} full><textarea name="description" rows={4} maxLength={1000} className={`${field} h-auto py-2`} placeholder="Amenities, floor, furnishing, nearby landmarks…" /></F>
        </Fieldset>

        <Fieldset title="Location">
          <F label="City / area" name="location"><select name="location" className={field}>{LOCATIONS.map((l) => <option key={l}>{l}</option>)}</select></F>
          <F label="Locality" name="locality" err={errors["locality"]}><input name="locality" className={field} placeholder="e.g. Andheri West" maxLength={80} /></F>
        </Fieldset>

        <Fieldset title="Photos">
          <div className="sm:col-span-2">
            <div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
              {files.map((f, i) => (
                <div key={i} className="relative aspect-square overflow-hidden rounded-lg border">
                  <img src={URL.createObjectURL(f)} alt="" className="h-full w-full object-cover" />
                  <button type="button" aria-label="Remove photo" onClick={() => setFiles(files.filter((_, j) => j !== i))}
                    className="absolute right-1 top-1 rounded-full bg-background/90 p-1"><X className="h-3 w-3" /></button>
                </div>
              ))}
              {files.length < 6 && (
                <label className="grid aspect-square cursor-pointer place-items-center rounded-lg border-2 border-dashed text-muted-foreground hover:border-primary hover:text-primary">
                  <ImagePlus className="h-6 w-6" />
                  <input type="file" accept="image/*" multiple className="sr-only" onChange={(e) => addFiles(e.target.files)} />
                </label>
              )}
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Up to 6 photos, 5 MB each.</p>
          </div>
        </Fieldset>

        <Fieldset title="Your contact details">
          <F label="Your name / company" name="advertiser_name" err={errors["advertiser_name"]}><input name="advertiser_name" className={field} maxLength={80} /></F>
          <F label="You are a" name="advertiser_role"><select name="advertiser_role" className={field}>{ROLES.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}</select></F>
          <F label="WhatsApp number" name="phone" err={errors["phone"]}><input name="phone" inputMode="numeric" className={field} placeholder="9876543210" maxLength={13} /></F>
          <F label="Email" name="email" err={errors["email"]}><input name="email" type="email" className={field} maxLength={255} /></F>
        </Fieldset>

        <Button type="submit" variant="accent" size="lg" className="w-full sm:w-auto" disabled={busy}>
          {busy && <Loader2 className="animate-spin" />} Publish listing
        </Button>
      </form>
    </div>
  );
}

function Fieldset({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <fieldset className="rounded-2xl border bg-card p-5 shadow-card sm:p-6">
      <legend className="px-2 font-display text-lg font-bold">{title}</legend>
      <div className="grid gap-4 sm:grid-cols-2">{children}</div>
    </fieldset>
  );
}

function F({ label, name, err, full, children }: { label: string; name: string; err?: string | undefined; full?: boolean; children: React.ReactNode }) {
  return (
    <label className={`block ${full ? "sm:col-span-2" : ""}`} htmlFor={name}>
      <span className="mb-1.5 block text-sm font-medium">{label}</span>
      {children}
      {err && <span className="mt-1 block text-xs font-medium text-destructive">{err}</span>}
    </label>
  );
}
