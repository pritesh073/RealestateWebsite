import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight, KeyRound, MapPin, Search, Home as HomeIcon, FileSignature } from "lucide-react";
import hero from "@/assets/hero.jpg";
import { Button } from "@/components/ui/button";
import { ListingCard } from "@/components/ListingCard";
import { PropertyIcon } from "@/components/PropertyIcon";
import { useListings } from "@/hooks/use-listings";
import { DEAL_TYPES, LOCATIONS, PROPERTY_TYPES } from "@/lib/properties";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "GharGhar — Buy, rent or lease property in Mumbai & Thane" },
      { name: "description", content: "Search flats, bungalows, offices, warehouses and plots across Mumbai, Navi Mumbai, Thane and Kalyan. Contact owners, agents and builders directly." },
      { property: "og:title", content: "GharGhar — Property listings across Mumbai region" },
      { property: "og:description", content: "Search properties and contact advertisers on WhatsApp or email." },
    ],
  }),
  component: Index,
});

const dealIcons = { buy: HomeIcon, lease: FileSignature, rent: KeyRound };
const selectCls =
  "h-12 w-full rounded-lg border border-input bg-background px-3 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-ring";

function Index() {
  const navigate = useNavigate();
  const [deal, setDeal] = useState("buy");
  const [type, setType] = useState("");
  const [location, setLocation] = useState("");
  const [q, setQ] = useState("");
  const { all } = useListings();

  const go = (e: React.FormEvent) => {
    e.preventDefault();
    navigate({ to: "/listings", search: { deal, type, location, q: q.trim().slice(0, 80), sort: "newest" } });
  };

  return (
    <>
      <section className="relative isolate overflow-hidden">
        <img src={hero} alt="Mumbai skyline at sunset" width={1920} height={1088} className="absolute inset-0 -z-10 h-full w-full object-cover" />
        <div className="absolute inset-0 -z-10 bg-hero-overlay" />
        <div className="mx-auto max-w-5xl px-4 pb-16 pt-20 text-center sm:px-6 sm:pt-28">
          <h1 className="text-4xl font-extrabold text-hero-foreground sm:text-6xl">
            Find your next property<br className="hidden sm:block" /> in the Mumbai region
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-base text-hero-foreground/85 sm:text-lg">
            Homes, offices, warehouses and land — straight from owners, agents and builders.
          </p>

          <form onSubmit={go} className="mx-auto mt-10 max-w-4xl rounded-2xl bg-card p-3 text-left shadow-lift sm:p-4">
            <div role="radiogroup" aria-label="What do you want to do" className="mb-3 flex gap-1 rounded-lg bg-secondary p-1">
              {DEAL_TYPES.map((d) => (
                <button
                  key={d.value}
                  type="button"
                  role="radio"
                  aria-checked={deal === d.value}
                  onClick={() => setDeal(d.value)}
                  className={cn(
                    "flex-1 rounded-md py-2 text-sm font-semibold transition-colors",
                    deal === d.value ? "bg-primary text-primary-foreground shadow" : "text-secondary-foreground hover:bg-background",
                  )}
                >
                  {d.label}
                </button>
              ))}
            </div>
            <div className="grid gap-2 sm:grid-cols-[1fr_1fr_1.4fr_auto]">
              <label className="sr-only" htmlFor="h-type">Property type</label>
              <select id="h-type" className={selectCls} value={type} onChange={(e) => setType(e.target.value)}>
                <option value="">All property types</option>
                {PROPERTY_TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
              </select>
              <label className="sr-only" htmlFor="h-loc">Location</label>
              <select id="h-loc" className={selectCls} value={location} onChange={(e) => setLocation(e.target.value)}>
                <option value="">All locations</option>
                {LOCATIONS.map((l) => <option key={l}>{l}</option>)}
              </select>
              <label className="sr-only" htmlFor="h-q">Search locality</label>
              <input id="h-q" className={selectCls} placeholder="Locality, e.g. Kharghar" value={q} onChange={(e) => setQ(e.target.value)} maxLength={80} />
              <Button type="submit" variant="accent" className="h-12 px-6 text-base">
                <Search /> Search
              </Button>
            </div>
          </form>
        </div>
      </section>

      <div className="mx-auto max-w-7xl space-y-16 px-4 pt-16 sm:px-6">
        <section>
          <SectionTitle step="1" title="Choose a property type" />
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
            {PROPERTY_TYPES.map((t) => (
              <Link key={t.value} to="/listings" search={{ type: t.value, deal: "", location: "", q: "", sort: "newest" }}
                className="group flex flex-col items-center gap-3 rounded-2xl border bg-card p-5 text-center shadow-card transition-all hover:-translate-y-0.5 hover:border-primary">
                <span className="grid h-14 w-14 place-items-center rounded-xl bg-secondary text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                  <PropertyIcon type={t.value} className="h-7 w-7" />
                </span>
                <span className="text-sm font-semibold">{t.label}</span>
              </Link>
            ))}
          </div>
        </section>

        <section>
          <SectionTitle step="2" title="Choose what you want to do" />
          <div className="grid gap-3 sm:grid-cols-3">
            {DEAL_TYPES.map((d) => {
              const Icon = dealIcons[d.value];
              return (
                <Link key={d.value} to="/listings" search={{ deal: d.value, type: "", location: "", q: "", sort: "newest" }}
                  className="group flex items-center gap-4 rounded-2xl border bg-card p-6 shadow-card transition-all hover:border-primary">
                  <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-accent/20 text-accent-foreground">
                    <Icon className="h-6 w-6" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-xl font-bold font-display">{d.label}</span>
                    <span className="block text-sm text-muted-foreground">{d.hint}</span>
                  </span>
                  <ArrowRight className="h-5 w-5 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-1" />
                </Link>
              );
            })}
          </div>
        </section>

        <section>
          <SectionTitle step="3" title="Choose a location" />
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            {LOCATIONS.map((l) => (
              <Link key={l} to="/listings" search={{ location: l, deal: "", type: "", q: "", sort: "newest" }}
                className="flex items-center gap-3 rounded-2xl border bg-card p-5 font-semibold shadow-card transition-all hover:border-primary">
                <MapPin className="h-5 w-5 shrink-0 text-accent" />
                <span className="min-w-0 flex-1 truncate">{l}</span>
                <span className="text-xs font-medium text-muted-foreground">{all.filter((x) => x.location === l).length}</span>
              </Link>
            ))}
          </div>
        </section>

        <section>
          <div className="mb-6 flex items-end justify-between gap-4">
            <div>
              <h2 className="text-2xl font-bold sm:text-3xl">Latest properties</h2>
              <p className="mt-1 text-sm text-muted-foreground">Cards marked “Example” are sample listings.</p>
            </div>
            <Button asChild variant="outline">
              <Link to="/listings">View all <ArrowRight /></Link>
            </Button>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {all.slice(0, 6).map((l) => <ListingCard key={l.id} l={l} />)}
          </div>
        </section>

        <section className="flex flex-col items-start gap-4 rounded-3xl bg-primary p-8 text-primary-foreground sm:flex-row sm:items-center sm:justify-between sm:p-12">
          <div>
            <h2 className="text-2xl font-bold sm:text-3xl">Own, sell or manage property?</h2>
            <p className="mt-2 text-primary-foreground/80">Owners, agents and builders can post a listing in minutes.</p>
          </div>
          <Button asChild variant="accent" size="lg"><Link to="/post">Post your property</Link></Button>
        </section>
      </div>
    </>
  );
}

function SectionTitle({ step, title }: { step: string; title: string }) {
  return (
    <div className="mb-5 flex items-center gap-3">
      <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-accent text-sm font-bold text-accent-foreground">{step}</span>
      <h2 className="text-2xl font-bold sm:text-3xl">{title}</h2>
    </div>
  );
}
