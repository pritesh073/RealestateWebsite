CREATE TABLE public.listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL CHECK (char_length(title) BETWEEN 3 AND 120),
  property_type text NOT NULL CHECK (property_type IN ('flat','house','bungalow','warehouse','office','plot')),
  transaction_type text NOT NULL CHECK (transaction_type IN ('buy','lease','rent')),
  location text NOT NULL CHECK (location IN ('Mumbai','Navi Mumbai','Thane','Kalyan')),
  locality text NOT NULL CHECK (char_length(locality) BETWEEN 2 AND 80),
  price numeric NOT NULL CHECK (price > 0 AND price < 100000000000),
  area_sqft integer CHECK (area_sqft IS NULL OR (area_sqft > 0 AND area_sqft < 10000000)),
  bedrooms integer CHECK (bedrooms IS NULL OR (bedrooms >= 0 AND bedrooms <= 50)),
  description text NOT NULL CHECK (char_length(description) BETWEEN 10 AND 1000),
  photos text[] NOT NULL DEFAULT '{}' CHECK (cardinality(photos) <= 6),
  advertiser_name text NOT NULL CHECK (char_length(advertiser_name) BETWEEN 2 AND 80),
  advertiser_role text NOT NULL CHECK (advertiser_role IN ('owner','agent','builder')),
  phone text NOT NULL CHECK (phone ~ '^[0-9]{10,13}$'),
  email text NOT NULL CHECK (char_length(email) <= 255 AND email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$'),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.listings TO anon, authenticated;
GRANT ALL ON public.listings TO service_role;
ALTER TABLE public.listings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view listings" ON public.listings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "Anyone can submit listings" ON public.listings FOR INSERT TO anon, authenticated WITH CHECK (true);

CREATE POLICY "Read listing photos" ON storage.objects FOR SELECT TO anon, authenticated USING (bucket_id = 'listing-photos');
CREATE POLICY "Upload listing photos" ON storage.objects FOR INSERT TO anon, authenticated WITH CHECK (bucket_id = 'listing-photos');